import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import * as cheerio from 'cheerio';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route to fetch competitor links
  app.post('/api/fetch-url', async (req, res) => {
    try {
      let { url } = req.body;
      if (!url.startsWith('http')) {
        url = 'https://' + url;
      }
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch: ${response.statusText}`);
      }
      const html = await response.text();
      
      const $ = cheerio.load(html);
      
      // Remove irrelevant elements
      $('script, style, nav, footer, header, noscript, svg, img').remove();
      
      // Get text, trim multiple spaces to single space
      let text = $('body').text().replace(/\s+/g, ' ').trim();
      
      // Limit text length to avoid blowing up context window (e.g., 5000 chars)
      if (text.length > 5000) {
        text = text.substring(0, 5000) + '...';
      }

      const title = $('title').text() || 'No title';
      
      res.json({ text, title });
    } catch (e: any) {
      console.error(e);
      res.status(500).json({ error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
