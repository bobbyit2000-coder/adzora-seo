import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Sparkles, Copy, Check, Loader2, PenTool, Type, ShoppingBag, Tags, PackageSearch, BookmarkPlus, ImagePlus, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

type Variation = {
  title: string;
  description: string;
};

type GeneratedContent = {
  variations: Variation[];
  bulletPoints: string[];
  keywords: string[];
  marketGaps?: string[];
  uniqueSellingPoints?: string[];
};

type Template = {
  id: string;
  name: string;
  productName: string;
  category: string;
  materials: string;
  features: string;
  targetPlatform: string;
  tone: string;
  competitorLinks?: string;
};

const AdzoraLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="arrow-grad" x1="25" y1="75" x2="90" y2="10" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#2563EB" />
        <stop offset="100%" stopColor="#A855F7" />
      </linearGradient>
    </defs>
    {/* The A outline */}
    <path d="M50 15 L18 85 L82 85 Z" stroke="currentColor" strokeWidth="8" strokeLinejoin="round" />
    {/* Inner triangle */}
    <path d="M50 40 L35 72 L65 72 Z" fill="currentColor" />
    
    {/* The Arrow */}
    <path d="M22 80 C 45 70, 65 50, 80 25 L 70 25 L 92 8 L 92 30 L 82 25 C 65 50, 45 75, 27 85 Z" fill="url(#arrow-grad)" />
  </svg>
);

const OutputPanel = React.memo(({
  outputRef,
  generatedContent,
  isGenerating,
  targetPlatform,
  copiedSection,
  copyToClipboard
}: {
  outputRef: React.RefObject<HTMLDivElement>;
  generatedContent: GeneratedContent | null;
  isGenerating: boolean;
  targetPlatform: string;
  copiedSection: string | null;
  copyToClipboard: (text: string, section: string) => void;
}) => {
  const [activeTab, setActiveTab] = React.useState(0);

  React.useEffect(() => {
    setActiveTab(0);
  }, [generatedContent]);

  return (
    <div ref={outputRef} className="w-full md:w-7/12 lg:w-2/3 md:h-full md:overflow-y-auto custom-scrollbar pb-12 md:pb-0 scroll-mt-24">
      <AnimatePresence mode="wait">
        {(!generatedContent && !isGenerating) ? (
          <motion.div 
            key="empty"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full flex flex-col items-center justify-center text-center p-8 bg-indigo-50/50 rounded-3xl border-2 border-dashed border-indigo-200"
          >
            <div className="bg-white w-20 h-20 rounded-2xl flex items-center justify-center mb-6 text-indigo-600 shadow-xl shadow-indigo-900/5 border-2 border-indigo-100">
               <Sparkles size={40} className="text-indigo-600" />
            </div>
            <h3 className="text-xl font-black text-slate-800 mb-3">Ready to write!</h3>
            <p className="text-slate-500 font-medium max-w-sm leading-relaxed">
              Fill out your product details on the left and hit generate to get perfectly optimized descriptions, titles, and tags for your handmade items.
            </p>
          </motion.div>
        ) : isGenerating ? (
          <motion.div 
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full flex flex-col items-center justify-center p-8"
          >
             <div className="relative w-24 h-24 mb-8">
                <div className="absolute inset-0 rounded-full border-t-4 border-slate-800 animate-spin"></div>
                <div className="absolute inset-2 rounded-full border-r-4 border-indigo-400 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                <div className="absolute inset-0 flex items-center justify-center text-slate-800">
                  <PenTool size={32} className="animate-pulse" />
                </div>
             </div>
             <h3 className="text-xl font-black text-slate-800">Crafting your listing...</h3>
             <p className="text-slate-500 font-medium mt-3 text-sm max-w-xs text-center leading-relaxed">Analyzing details and optimizing for {targetPlatform} search algorithms.</p>
          </motion.div>
        ) : generatedContent && generatedContent.variations ? (
          <motion.div
            key="content"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {/* A/B Tabs */}
            {generatedContent.variations.length > 1 && (
              <div className="flex gap-2 p-1.5 bg-slate-100 rounded-2xl w-max border-2 border-slate-200/50">
                {generatedContent.variations.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveTab(i)}
                    className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === i ? 'bg-white text-indigo-700 shadow-sm border-2 border-slate-200/50' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50 border-2 border-transparent'}`}
                  >
                    Variation {String.fromCharCode(65 + i)}
                  </button>
                ))}
              </div>
            )}

            {/* Title */}
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl shadow-indigo-900/5 border-2 border-slate-100 relative group line-height-relaxed">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                   <Type size={16} className="text-indigo-400" /> SEO Optimized Title
                </h3>
                <button 
                  onClick={() => copyToClipboard(generatedContent.variations[activeTab]?.title || '', 'title')}
                  className="p-2.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 border-2 border-transparent rounded-xl transition-colors font-bold uppercase text-[10px] tracking-wider flex items-center gap-1.5"
                  title="Copy Title"
                >
                  {copiedSection === 'title' ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copiedSection === 'title' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-xl sm:text-3xl font-black text-slate-800 leading-tight break-words">{generatedContent.variations[activeTab]?.title}</p>
            </div>

            {/* Description */}
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl shadow-indigo-900/5 border-2 border-slate-100 relative group line-height-relaxed">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                   <ShoppingBag size={16} className="text-sky-500" /> Product Description
                </h3>
                <button 
                  onClick={() => copyToClipboard(generatedContent.variations[activeTab]?.description || '', 'description')}
                  className="p-2.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 border-2 border-transparent rounded-xl transition-colors font-bold uppercase text-[10px] tracking-wider flex items-center gap-1.5"
                  title="Copy Description"
                >
                  {copiedSection === 'description' ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copiedSection === 'description' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <div className="bg-slate-50 rounded-2xl p-6 border-2 border-slate-100 prose prose-slate max-w-none text-slate-700 whitespace-pre-wrap leading-relaxed font-medium">
                {generatedContent.variations[activeTab]?.description}
              </div>
            </div>

            {/* Bullet Points */}
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl shadow-indigo-900/5 border-2 border-slate-100 relative group line-height-relaxed">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                   <Check size={16} className="text-indigo-400" /> Key Features & Materials
                </h3>
                <button 
                  onClick={() => copyToClipboard(generatedContent.bulletPoints.map((b: string) => `• ${b}`).join('\n'), 'bullets')}
                  className="p-2.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 border-2 border-transparent rounded-xl transition-colors font-bold uppercase text-[10px] tracking-wider flex items-center gap-1.5"
                  title="Copy Bullets"
                >
                  {copiedSection === 'bullets' ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copiedSection === 'bullets' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <ul className="space-y-4 bg-slate-50 rounded-2xl p-6 md:p-8 border-2 border-slate-100">
                {generatedContent.bulletPoints.map((bullet: string, idx: number) => (
                  <li key={idx} className="flex gap-4 text-slate-700 font-medium items-start">
                    <span className="text-indigo-600 mt-0.5 flex-shrink-0 bg-white rounded-full p-1.5 border-2 border-indigo-100 shadow-sm"><Check size={14} strokeWidth={3} /></span>
                    <span className="leading-relaxed text-base pt-0.5">{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Market Gaps & Unique Selling Points */}
            {(generatedContent.marketGaps?.length || generatedContent.uniqueSellingPoints?.length) ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {generatedContent.marketGaps && generatedContent.marketGaps.length > 0 && (
                  <div className="bg-indigo-50 rounded-3xl p-6 shadow-sm border-2 border-indigo-100 flex-1">
                    <h3 className="text-xs font-black uppercase tracking-widest text-indigo-600 flex items-center gap-2 mb-4">
                       <PackageSearch size={16} /> Market Gaps
                    </h3>
                    <ul className="space-y-3">
                      {generatedContent.marketGaps.map((gap: string, idx: number) => (
                        <li key={idx} className="flex gap-3 text-slate-700 font-medium items-start">
                          <span className="text-indigo-600 mt-1"><Check size={14} strokeWidth={3} /></span>
                          <span className="text-sm leading-relaxed">{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {generatedContent.uniqueSellingPoints && generatedContent.uniqueSellingPoints.length > 0 && (
                  <div className="bg-sky-50 rounded-3xl p-6 shadow-sm border-2 border-sky-100 flex-1">
                    <h3 className="text-xs font-black uppercase tracking-widest text-sky-700 flex items-center gap-2 mb-4">
                       <Sparkles size={16} /> Unique Selling Points
                    </h3>
                    <ul className="space-y-3">
                      {generatedContent.uniqueSellingPoints.map((usp: string, idx: number) => (
                        <li key={idx} className="flex gap-3 text-slate-700 font-medium items-start">
                          <span className="text-sky-600 mt-1"><Check size={14} strokeWidth={3} /></span>
                          <span className="text-sm leading-relaxed">{usp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : null}

            {/* Keywords / Tags */}
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl shadow-indigo-900/5 border-2 border-slate-100 relative group line-height-relaxed mb-8">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                   <Tags size={16} className="text-sky-500" /> SEO Tags & Keywords
                </h3>
                <button 
                  onClick={() => copyToClipboard(generatedContent.keywords.join(', '), 'tags')}
                  className="p-2.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 border-2 border-transparent rounded-xl transition-colors font-bold uppercase text-[10px] tracking-wider flex items-center gap-1.5"
                  title="Copy Tags"
                >
                  {copiedSection === 'tags' ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copiedSection === 'tags' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <div className="flex flex-wrap gap-3">
                 {generatedContent.keywords.map((kw: string, idx: number) => (
                   <span key={idx} className="px-4 py-2 bg-sky-50 border-2 border-sky-200 text-sky-800 text-xs font-bold rounded-xl shadow-sm whitespace-nowrap">
                     {kw}
                   </span>
                 ))}
              </div>
              <div className="mt-8 pt-6 border-t-2 border-slate-100 flex justify-between items-center text-xs font-bold text-slate-400 uppercase tracking-widest">
                <span>{generatedContent.keywords.length} tags generated</span>
                <button 
                   onClick={() => copyToClipboard(generatedContent.keywords.join(', '), 'tags-raw')}
                   className="hover:text-indigo-600 transition-colors flex items-center gap-1"
                >
                  <Copy size={14} /> Copy as Comma-Separated
                </button>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
});

export default function App() {
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('Jewelry');
  const [materials, setMaterials] = useState('');
  const [features, setFeatures] = useState('');
  const [targetPlatform, setTargetPlatform] = useState('Etsy');
  const [tone, setTone] = useState('Warm & Friendly');
  const [competitorLinks, setCompetitorLinks] = useState('');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [templateNameInput, setTemplateNameInput] = useState('');

  const [templates, setTemplates] = useState<Template[]>(() => {
    const saved = localStorage.getItem('seo_templates');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('seo_templates', JSON.stringify(templates));
  }, [templates]);

  const categories = ['Jewelry', 'Ceramics & Pottery', 'Art & Collectibles', 'Clothing & Shoes', 'Home Decor', 'Accessories', 'Toys & Games', 'Other'];
  const platforms = [
    'Etsy', 
    'Shopify', 
    'Amazon Handmade', 
    'WooCommerce', 
    'eBay', 
    'Pinterest', 
    'Instagram Shop', 
    'TikTok Shop', 
    'Facebook Marketplace', 
    'BigCommerce', 
    'Squarespace', 
    'Wix', 
    'General E-commerce'
  ];
  const tones = ['Warm & Friendly', 'Professional', 'Luxury & Elegant', 'Playful & Quirky', 'Storytelling', 'Minimalist'];

  const handleSaveTemplateClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!productName && !materials && !features) {
      setError("Please fill out some product details to save a template.");
      return;
    }
    setTemplateNameInput(productName || "My Template");
    setIsTemplateModalOpen(true);
  };

  const confirmSaveTemplate = () => {
    if (!templateNameInput.trim()) return;

    const newTemplate: Template = {
      id: Date.now().toString(),
      name: templateNameInput,
      productName,
      category,
      materials,
      features,
      targetPlatform,
      tone,
      competitorLinks,
    };
    setTemplates([...templates, newTemplate]);
    setIsTemplateModalOpen(false);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImageFile(null);
    setSelectedImagePreview(null);
  };

  const handleGenerateTextAndImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName && !selectedImageFile) {
       setError("Please provide a product name or upload an image.");
       return;
    }
    
    setIsGenerating(true);
    setGeneratedContent(null);
    setError(null);

    let competitorData = '';
    if (competitorLinks.trim()) {
      const urls = competitorLinks.split('\n').map(link => link.trim()).filter(link => link);
      const fetchPromises = urls.map(async (url) => {
         try {
            const res = await fetch('/api/fetch-url', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ url })
            });
            const data = await res.json();
            return data.text ? `\nCompetitor (${url}):\n${data.text}` : '';
         } catch (e) {
            console.error("Failed to fetch competitor link:", url, e);
            return '';
         }
      });
      const results = await Promise.all(fetchPromises);
      competitorData = results.join('\n');
    }

    const textPrompt = `
You are an expert SEO copywriter specializing in handmade and artisan goods.
Your task is to craft a highly optimized, keyword-rich product description for an e-commerce platform. Focus deeply on the unique characteristics, creation process, and materials. Avoid common wording and cliché phrasing, and instead highlight the specific craftsmanship and artistry behind this piece to make it stand out.

${selectedImageFile ? "I have provided an image of the product. Analyze the image to identify the product, describe its visual details, materials, and craftsmanship. Extract key features to generate a compelling product description for e-commerce." : ""}

Product Details provided by the user:
- Name/Concept: ${productName || "Unknown (infer from image)"}
- Category: ${category}
- Materials Used: ${materials || "Infer from image if possible"}
- Unique Features/Details: ${features || "Infer from image if possible"}
- Target Platform: ${targetPlatform}
- Desired Tone: ${tone}

${competitorData ? `\nCompetitor Information (Analyze this to identify market gaps and suggest unique selling points for the user's product):\n${competitorData}\n` : ""}

Return the response in the following strict JSON format ONLY. Do not include markdown formatting or extra text outside the JSON object.
{
  "variations": [
    {
      "title": "Variation A: A highly optimized, click-worthy SEO title (max 70 characters preferably, but follow platform best practices). Make it descriptive and distinct.",
      "description": "Variation A: A compelling 2-3 paragraph description that weaves in SEO keywords naturally. Focus deeply on the unique characteristics, the creation process, and the specific materials used. Avoid generic phrasing; emphasize the manual craftsmanship. Write in the requested tone."
    },
    {
      "title": "Variation B: A different angle or emotional hook for the SEO title targeting secondary keywords.",
      "description": "Variation B: A different structure or tone for the description, perhaps highlighting different features or using a different emotional appeal."
    }
  ],
  "bulletPoints": ["Bullet 1 highlighting a specific aspect of the creation process or material", "Bullet 2 detailing a unique feature...", "Bullet 3...", "Bullet 4..."],
  "keywords": ["keyword1", "long tail keyword 2 focusing on materials/process", "keyword 3", ...]${competitorData ? `,\n  "marketGaps": ["Gap 1 found in competitors...", "Gap 2..."],\n  "uniqueSellingPoints": ["How my product fills the gap...", "Another USP..."]` : ""}
}
`;

    let promptContents: any[] = [];
    if (selectedImagePreview && selectedImageFile) {
      const base64Data = selectedImagePreview.split(',')[1];
      promptContents.push({
        inlineData: {
          data: base64Data,
          mimeType: selectedImageFile.type,
        }
      });
    }
    promptContents.push({ text: textPrompt });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: promptContents,
        config: {
          temperature: 0.7,
          responseMimeType: "application/json",
        }
      });

      const responseText = response.text;
      if (responseText) {
        const parsedData = JSON.parse(responseText);
        setGeneratedContent(parsedData);
        setTimeout(() => {
          if (window.innerWidth < 768 && outputRef.current) {
            outputRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }, 100);
      } else {
         setError("Received an empty response from the AI. Please try again.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred while generating the description.");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = useCallback((text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  }, []);

  return (
    <div className="min-h-screen bg-indigo-50 text-slate-800 font-sans selection:bg-indigo-200 selection:text-indigo-900 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b-4 border-indigo-200 sticky top-0 z-10 w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-[5rem] py-3 sm:py-0 flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            <AdzoraLogo className="w-8 h-8 sm:w-10 sm:h-10 text-slate-900 flex-shrink-0" />
            <h1 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight whitespace-nowrap">ADZORA <span className="text-indigo-600">SEO</span></h1>
          </div>
          <div className="flex items-center w-full sm:w-auto">
            <div className="relative w-full sm:w-auto">
              <select
                 className="w-full sm:w-auto appearance-none px-4 sm:px-5 py-2.5 bg-indigo-100 text-indigo-700 font-bold rounded-full text-xs sm:text-sm cursor-pointer pr-8 sm:pr-10 outline-none focus:ring-4 focus:ring-indigo-200 transition-all border-2 border-transparent hover:border-indigo-200"
                 onChange={(e) => {
                   const tId = e.target.value;
                   if (tId === "") return;
                   const t = templates.find(temp => temp.id === tId);
                   if (t) {
                     setProductName(t.productName);
                     setCategory(t.category);
                     setMaterials(t.materials);
                     setFeatures(t.features);
                     setTargetPlatform(t.targetPlatform);
                     setTone(t.tone);
                     setCompetitorLinks(t.competitorLinks || '');
                   }
                   e.target.value = "";
                 }}
                 value=""
              >
                 <option value="" disabled>Templates ({templates.length})</option>
                 {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-indigo-700">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Template Modal */}
      {isTemplateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-sm w-full shadow-2xl border-2 border-slate-100">
            <h3 className="text-xl font-black text-slate-800 mb-4">Save Template</h3>
            <p className="text-sm text-slate-500 mb-4">Give your template a memorable name to easily reload it later.</p>
            <input
              type="text"
              className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm mb-6"
              placeholder="e.g. Vintage Necklace Base"
              value={templateNameInput}
              onChange={e => setTemplateNameInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') confirmSaveTemplate();
                if (e.key === 'Escape') setIsTemplateModalOpen(false);
              }}
              autoFocus
            />
            <div className="flex gap-3">
              <button
                type="button"
                className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-colors text-sm"
                onClick={() => setIsTemplateModalOpen(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-600 text-white font-bold rounded-xl transition-colors text-sm shadow-md"
                onClick={confirmSaveTemplate}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8 flex flex-col md:flex-row gap-6 sm:gap-8 md:h-[calc(100vh-5rem)]">
        
        {/* Input Column */}
        <div className="w-full md:w-5/12 lg:w-1/3 flex flex-col md:h-full bg-white rounded-3xl shadow-xl shadow-indigo-900/5 border-2 border-slate-100 md:overflow-hidden">
           <div className="p-5 sm:p-6 border-b-2 border-slate-100 bg-indigo-50/30">
             <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
               <PackageSearch className="text-indigo-600" size={24} />
               Product Details
             </h2>
             <p className="text-sm text-slate-500 font-medium mt-2 leading-relaxed">Provide details about your products to generate tailored SEO content.</p>
           </div>
           
           <div className="p-5 sm:p-6 md:overflow-y-auto flex-1 custom-scrollbar">
             <form onSubmit={handleGenerateTextAndImage} className="space-y-5 sm:space-y-6">
               
               <div>
                 <label htmlFor="productName" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Product Name / Concept</label>
                 <input
                   type="text"
                   id="productName"
                   value={productName}
                   onChange={(e) => setProductName(e.target.value)}
                   placeholder="e.g. Organic Indigo-Dyed Linen Tote"
                   className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm"
                 />
               </div>

               <div>
                 <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Product Image (Optional)</label>
                 {selectedImagePreview ? (
                   <div className="relative w-full h-48 bg-slate-50 border-2 border-slate-200 rounded-2xl overflow-hidden flex items-center justify-center">
                     <img src={selectedImagePreview} alt="Preview" className="w-full h-full object-cover" />
                     <button 
                       type="button" 
                       onClick={removeImage}
                       className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors"
                     >
                       <X size={16} />
                     </button>
                   </div>
                 ) : (
                   <label className="w-full h-32 flex flex-col items-center justify-center p-4 bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl hover:border-indigo-400 hover:bg-indigo-50/30 cursor-pointer transition-colors">
                     <ImagePlus className="text-slate-400 mb-2" size={24} />
                     <span className="text-sm font-bold text-slate-500">Upload Image to Analyze</span>
                     <span className="text-[10px] text-slate-400 font-medium mt-1">Let AI extract the details</span>
                     <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                   </label>
                 )}
               </div>

               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div>
                   <label htmlFor="category" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Category</label>
                   <select
                     id="category"
                     value={category}
                     onChange={(e) => setCategory(e.target.value)}
                     className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm"
                   >
                     {categories.map(c => <option key={c} value={c}>{c}</option>)}
                   </select>
                 </div>
                 <div>
                   <label htmlFor="targetPlatform" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Platform</label>
                   <select
                     id="targetPlatform"
                     value={targetPlatform}
                     onChange={(e) => setTargetPlatform(e.target.value)}
                     className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm"
                   >
                     {platforms.map(p => <option key={p} value={p}>{p}</option>)}
                   </select>
                 </div>
               </div>

               <div>
                 <label htmlFor="materials" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Materials Used</label>
                 <input
                   type="text"
                   id="materials"
                   value={materials}
                   onChange={(e) => setMaterials(e.target.value)}
                   placeholder="e.g. Linen, Natural Indigo"
                   className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm"
                 />
               </div>

               <div>
                 <label htmlFor="features" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Unique Features</label>
                 <textarea
                   id="features"
                   value={features}
                   onChange={(e) => setFeatures(e.target.value)}
                   placeholder="e.g. Hand-stitched, Reversible, Eco-friendly"
                   rows={4}
                   className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm resize-none shadow-sm"
                 />
               </div>

               <div>
                 <label htmlFor="competitorLinks" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Competitor Analysis (URLs)</label>
                 <textarea
                   id="competitorLinks"
                   value={competitorLinks}
                   onChange={(e) => setCompetitorLinks(e.target.value)}
                   placeholder="Optional: Paste competitor product links (one per line) to analyze market gaps"
                   rows={3}
                   className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm resize-none shadow-sm"
                 />
               </div>

               <div>
                   <label htmlFor="tone" className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Brand Tone</label>
                   <select
                     id="tone"
                     value={tone}
                     onChange={(e) => setTone(e.target.value)}
                     className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-indigo-400 transition-colors text-sm shadow-sm"
                   >
                     {tones.map(t => <option key={t} value={t}>{t}</option>)}
                   </select>
               </div>

               {error && (
                 <div className="p-4 bg-red-50 text-red-700 text-sm font-bold rounded-2xl border-2 border-red-200">
                   {error}
                 </div>
               )}

             </form>
           </div>
           
           <div className="p-5 sm:p-6 border-t-2 border-slate-100 bg-white flex flex-col gap-3">
             <button
                onClick={handleGenerateTextAndImage}
                disabled={isGenerating}
                className="w-full py-4 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-400 text-white font-black uppercase tracking-wider rounded-2xl flex items-center justify-center gap-2 transition-colors shadow-lg focus:ring-4 focus:ring-slate-200 focus:outline-none text-sm"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    Generating Magic...
                  </>
                ) : (
                  <>
                    <Sparkles size={20} className="text-indigo-400" />
                    Generate SEO Copy
                  </>
                )}
              </button>
              <button
                onClick={handleSaveTemplateClick}
                className="w-full py-3 bg-white border-2 border-slate-200 hover:border-indigo-400 hover:text-indigo-600 text-slate-500 font-bold uppercase tracking-wider rounded-xl transition-colors focus:outline-none focus:ring-4 focus:ring-indigo-100 text-xs flex items-center justify-center gap-2"
              >
                 <BookmarkPlus size={16} /> Save as Template
              </button>
           </div>
        </div>

        {/* Output Column */}
        <OutputPanel
          outputRef={outputRef}
          generatedContent={generatedContent}
          isGenerating={isGenerating}
          targetPlatform={targetPlatform}
          copiedSection={copiedSection}
          copyToClipboard={copyToClipboard}
        />
      </main>

      {/* Footer */}
      <footer className="w-full bg-slate-900 border-t-4 border-indigo-500 py-8 px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center justify-center gap-2 mt-auto">
        <p className="text-slate-400 font-medium text-sm sm:text-base">Website created by <span className="text-indigo-400 font-bold">Syed Uzair Uddin</span></p>
        <p className="text-indigo-300/80 font-black tracking-widest uppercase text-xs sm:text-sm">Your Vision, My Code</p>
      </footer>
    </div>
  );
}
